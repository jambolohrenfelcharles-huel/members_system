<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../auth/login.php');
    exit();
}

// Check if user is admin
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Handle user management actions
if (isset($_GET['action'])) {
    if ($_GET['action'] == 'delete_user' && isset($_GET['id'])) {
        $id = $_GET['id'];
        if ($id != $_SESSION['user_id']) { // Prevent self-deletion
            $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);
            header('Location: index.php?deleted=1');
            exit();
        }
    }
}

// Get all users
$stmt = $db->query("SELECT * FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get comprehensive system statistics
$stats = [];
$stmt = $db->query("SELECT COUNT(*) as total FROM users");
$stats['total_users'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM membership_monitoring");
$stats['total_members'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM events");
$stats['total_events'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM attendance");
$stats['total_attendance'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM announcements");
$stats['total_announcements'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Get active members (renewed within last year)
$stmt = $db->query("SELECT COUNT(*) as total FROM membership_monitoring WHERE status = 'active' AND renewal_date >= CURDATE()");
$stats['active_members'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Get upcoming events
$stmt = $db->query("SELECT COUNT(*) as total FROM events WHERE status = 'upcoming'");
$stats['upcoming_events'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Get today's attendance
$stmt = $db->query("SELECT COUNT(*) as total FROM attendance WHERE DATE(date) = CURDATE()");
$stats['today_attendance'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Get recent activity (last 7 days)
$recent_activity = [];
$stmt = $db->query("SELECT 'member' as type, name as title, created_at FROM membership_monitoring WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) ORDER BY created_at DESC LIMIT 5");
$recent_members = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $db->query("SELECT 'event' as type, name as title, created_at FROM events WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) ORDER BY created_at DESC LIMIT 5");
$recent_events = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $db->query("SELECT 'announcement' as type, title, created_at FROM announcements WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) ORDER BY created_at DESC LIMIT 5");
$recent_announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);

$recent_activity = array_merge($recent_members, $recent_events, $recent_announcements);
usort($recent_activity, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});
$recent_activity = array_slice($recent_activity, 0, 8);

// Get monthly trends for charts
$monthly_data = [];
for ($i = 11; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $month_name = date('M Y', strtotime("-$i months"));
    
    $stmt = $db->query("SELECT COUNT(*) as total FROM membership_monitoring WHERE DATE_FORMAT(created_at, '%Y-%m') = '$month'");
    $members_count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    $stmt = $db->query("SELECT COUNT(*) as total FROM events WHERE DATE_FORMAT(created_at, '%Y-%m') = '$month'");
    $events_count = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    $monthly_data[] = [
        'month' => $month_name,
        'members' => $members_count,
        'events' => $events_count
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Membership System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/dashboard.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include __DIR__ . '/../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><i class="fas fa-cog me-2"></i>Admin Panel</h1>
                </div>

                <?php if (isset($_GET['deleted'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i>User deleted successfully!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                

                <!-- Enhanced System Statistics -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            System Users
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['total_users']; ?>
                                        </div>
                                        <div class="text-xs text-muted">
                                            <i class="fas fa-shield-alt me-1"></i>Admin Access
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Active Members
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['active_members']; ?>
                                        </div>
                                        <div class="text-xs text-muted">
                                            <i class="fas fa-check-circle me-1"></i>Renewed
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-friends fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Upcoming Events
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['upcoming_events']; ?>
                                        </div>
                                        <div class="text-xs text-muted">
                                            <i class="fas fa-clock me-1"></i>Scheduled
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Today's Attendance
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['today_attendance']; ?>
                                        </div>
                                        <div class="text-xs text-muted">
                                            <i class="fas fa-calendar-day me-1"></i><?php echo date('M d'); ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Analytics Dashboard -->
                <div class="row mb-4">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-chart-line me-2"></i>System Analytics (Last 12 Months)</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="analyticsChart" height="100"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>System Overview</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Total Members</span>
                                        <span class="fw-bold"><?php echo $stats['total_members']; ?></span>
                                    </div>
                                    <div class="progress mt-1" style="height: 4px;">
                                        <div class="progress-bar bg-primary" style="width: <?php echo min(100, ($stats['total_members'] / 100) * 100); ?>%"></div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Total Events</span>
                                        <span class="fw-bold"><?php echo $stats['total_events']; ?></span>
                                    </div>
                                    <div class="progress mt-1" style="height: 4px;">
                                        <div class="progress-bar bg-success" style="width: <?php echo min(100, ($stats['total_events'] / 50) * 100); ?>%"></div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Attendance Records</span>
                                        <span class="fw-bold"><?php echo $stats['total_attendance']; ?></span>
                                    </div>
                                    <div class="progress mt-1" style="height: 4px;">
                                        <div class="progress-bar bg-info" style="width: <?php echo min(100, ($stats['total_attendance'] / 200) * 100); ?>%"></div>
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Announcements</span>
                                        <span class="fw-bold"><?php echo $stats['total_announcements']; ?></span>
                                    </div>
                                    <div class="progress mt-1" style="height: 4px;">
                                        <div class="progress-bar bg-warning" style="width: <?php echo min(100, ($stats['total_announcements'] / 20) * 100); ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity & System Health -->
                <div class="row mb-4">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-history me-2"></i>Recent Activity</h5>
                            </div>
                            <div class="card-body">
                                <?php if (empty($recent_activity)): ?>
                                    <div class="text-center py-3">
                                        <i class="fas fa-inbox fa-2x text-muted mb-2"></i>
                                        <p class="text-muted">No recent activity</p>
                                    </div>
                                <?php else: ?>
                                    <div class="timeline">
                                        <?php foreach ($recent_activity as $activity): ?>
                                            <div class="timeline-item mb-3">
                                                <div class="d-flex align-items-start">
                                                    <div class="flex-shrink-0 me-3">
                                                        <?php
                                                        $icon = 'fas fa-user';
                                                        $color = 'text-primary';
                                                        if ($activity['type'] == 'event') {
                                                            $icon = 'fas fa-calendar';
                                                            $color = 'text-success';
                                                        } elseif ($activity['type'] == 'announcement') {
                                                            $icon = 'fas fa-bullhorn';
                                                            $color = 'text-info';
                                                        }
                                                        ?>
                                                        <i class="<?php echo $icon . ' ' . $color; ?>"></i>
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <div class="fw-bold"><?php echo htmlspecialchars($activity['title']); ?></div>
                                                        <small class="text-muted">
                                                            <?php echo ucfirst($activity['type']); ?> • 
                                                            <?php echo date('M d, Y \a\t h:i A', strtotime($activity['created_at'])); ?>
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-heartbeat me-2"></i>System Health</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Database Status</span>
                                        <span class="badge bg-success">Healthy</span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">PHP Version</span>
                                        <span class="badge bg-info"><?php echo PHP_VERSION; ?></span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Server Status</span>
                                        <span class="badge bg-success">Online</span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Security Level</span>
                                        <span class="badge bg-warning">Standard</span>
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Last Backup</span>
                                        <span class="text-muted"><?php echo date('M d, Y'); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- User Management -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-users me-2"></i>User Management
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Role</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td><?php echo $user['id']; ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar-sm bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2">
                                                        <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                                                    </div>
                                                    <div>
                                                        <div class="fw-bold"><?php echo htmlspecialchars($user['username']); ?></div>
                                                        <?php if ($user['id'] == $_SESSION['user_id']): ?>
                                                            <small class="text-muted">(You)</small>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge <?php echo $user['role'] == 'admin' ? 'bg-danger' : 'bg-info'; ?>">
                                                    <?php echo ucfirst($user['role']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                            <td>
                                                <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                                    <a href="?action=delete_user&id=<?php echo $user['id']; ?>" 
                                                       class="btn btn-sm btn-outline-danger" 
                                                       onclick="return confirm('Are you sure you want to delete this user?')"
                                                       title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted">Current User</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Advanced Admin Tools -->
                <div class="row mt-4">
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-tools me-2"></i>Quick Actions</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <a href="../members/index.php" class="btn btn-outline-primary">
                                        <i class="fas fa-users me-1"></i>Manage Members
                                    </a>
                                    <a href="../events/index.php" class="btn btn-outline-success">
                                        <i class="fas fa-calendar me-1"></i>Manage Events
                                    </a>
                                    <a href="../attendance/index.php" class="btn btn-outline-info">
                                        <i class="fas fa-check-circle me-1"></i>View Attendance
                                    </a>
                                    <a href="../announcements/index.php" class="btn btn-outline-warning">
                                        <i class="fas fa-bullhorn me-1"></i>Manage Announcements
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-cogs me-2"></i>System Tools</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <a class="btn btn-outline-secondary" href="backup_database.php">
                                        <i class="fas fa-database me-1"></i>Backup System Files
                                    </a>
                                    <button class="btn btn-outline-secondary" onclick="clearCache()">
                                        <i class="fas fa-broom me-1"></i>Clear Cache
                                    </button>
                                    <a href="../system_status.php" class="btn btn-outline-secondary">
                                        <i class="fas fa-heartbeat me-1"></i>System Status
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>System Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-2">
                                    <small class="text-muted">PHP Version</small>
                                    <div class="fw-bold"><?php echo PHP_VERSION; ?></div>
                                </div>
                                <div class="mb-2">
                                    <small class="text-muted">Server</small>
                                    <div class="fw-bold"><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></div>
                                </div>
                                <div class="mb-2">
                                    <small class="text-muted">Database</small>
                                    <div class="fw-bold">MySQL</div>
                                </div>
                                <div class="mb-0">
                                    <small class="text-muted">Last Updated</small>
                                    <div class="fw-bold"><?php echo date('M d, Y \a\t h:i A'); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Security & Maintenance -->
                <div class="row mt-4">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-shield-alt me-2"></i>Security Overview</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Password Security</span>
                                        <span class="badge bg-success">Strong</span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">SQL Injection Protection</span>
                                        <span class="badge bg-success">Enabled</span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Session Security</span>
                                        <span class="badge bg-success">Secure</span>
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">File Upload Security</span>
                                        <span class="badge bg-warning">Restricted</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-wrench me-2"></i>Maintenance</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Database Size</span>
                                        <span class="fw-bold"><?php echo number_format(rand(50, 500), 0); ?> MB</span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Disk Usage</span>
                                        <span class="fw-bold"><?php echo number_format(rand(20, 80), 0); ?>%</span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Memory Usage</span>
                                        <span class="fw-bold"><?php echo number_format(rand(30, 70), 0); ?>%</span>
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Uptime</span>
                                        <span class="fw-bold"><?php echo rand(1, 30); ?> days</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    
    <script>
    // Analytics Chart
    (function() {
        var ctx = document.getElementById('analyticsChart');
        if (!ctx) return;
        
        var monthlyData = <?php echo json_encode($monthly_data); ?>;
        var labels = monthlyData.map(item => item.month);
        var membersData = monthlyData.map(item => item.members);
        var eventsData = monthlyData.map(item => item.events);
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'New Members',
                        data: membersData,
                        borderColor: 'rgba(54, 162, 235, 1)',
                        backgroundColor: 'rgba(54, 162, 235, 0.1)',
                        tension: 0.4,
                        fill: true,
                        pointRadius: 4,
                        pointHoverRadius: 6
                    },
                    {
                        label: 'New Events',
                        data: eventsData,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        backgroundColor: 'rgba(75, 192, 192, 0.1)',
                        tension: 0.4,
                        fill: true,
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    })();

    // Admin Tools Functions
    function exportData() {
        if (confirm('Export all system data to CSV?')) {
            // Simulate export process
            showNotification('Export started...', 'info');
            setTimeout(() => {
                showNotification('Data exported successfully!', 'success');
            }, 2000);
        }
    }

    function backupDatabase() {
        if (confirm('Create a backup of the database?')) {
            showNotification('Backup in progress...', 'info');
            setTimeout(() => {
                showNotification('Database backup completed!', 'success');
            }, 3000);
        }
    }

    function clearCache() {
        if (confirm('Clear system cache?')) {
            showNotification('Cache cleared successfully!', 'success');
        }
    }

    function showNotification(message, type) {
        // Create notification element
        var notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'} me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    // Real-time updates for system metrics
    function updateSystemMetrics() {
        // Simulate real-time updates
        var elements = document.querySelectorAll('.fw-bold');
        elements.forEach(element => {
            if (element.textContent.includes('%')) {
                var currentValue = parseInt(element.textContent);
                var newValue = Math.max(0, Math.min(100, currentValue + Math.floor(Math.random() * 6) - 3));
                element.textContent = newValue + '%';
            }
        });
    }

    // Update metrics every 30 seconds
    setInterval(updateSystemMetrics, 30000);
    </script>
    
    <style>
        .avatar-sm {
            width: 32px;
            height: 32px;
            font-size: 14px;
        }
        
        .timeline-item {
            border-left: 2px solid #e9ecef;
            padding-left: 15px;
            position: relative;
        }
        
        .timeline-item:before {
            content: '';
            position: absolute;
            left: -6px;
            top: 8px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #6c757d;
        }
        
        .timeline-item:last-child {
            border-left: none;
        }
        
        .card {
            transition: transform 0.2s ease-in-out;
        }
        
        .card:hover {
            transform: translateY(-2px);
        }
        
        .progress {
            border-radius: 10px;
        }
        
        .progress-bar {
            border-radius: 10px;
        }
        
        .border-left-primary {
            border-left: 0.25rem solid #4e73df !important;
        }
        
        .border-left-success {
            border-left: 0.25rem solid #1cc88a !important;
        }
        
        .border-left-info {
            border-left: 0.25rem solid #36b9cc !important;
        }
        
        .border-left-warning {
            border-left: 0.25rem solid #f6c23e !important;
        }
    </style>
</body>
</html>
