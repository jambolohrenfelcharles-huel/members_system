<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();



// Get dashboard statistics
$stats = [];

// Total members
$stmt = $db->query("SELECT COUNT(*) as total FROM membership_monitoring");
$stats['total_members'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Total events
$stmt = $db->query("SELECT COUNT(*) as total FROM events");
$stats['total_events'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Upcoming events
$stmt = $db->query("SELECT COUNT(*) as total FROM events WHERE status = 'upcoming'");
$stats['upcoming_events'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Today's attendance
$stmt = $db->query("SELECT COUNT(*) as total FROM attendance WHERE DATE(date) = CURDATE()");
$stats['today_attendance'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Recent announcements
$stmt = $db->query("SELECT * FROM announcements ORDER BY created_at DESC LIMIT 5");
$recent_announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Recent events
$stmt = $db->query("SELECT * FROM events ORDER BY event_date DESC LIMIT 5");
$recent_events = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Recent News Feed
$stmt = $db->query("SELECT * FROM news_feed ORDER BY created_at DESC LIMIT 5");
$recent_news_feed = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle delete action
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $stmt = $db->prepare("DELETE FROM news_feed WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: index.php?deleted=1');
    exit();
}

// Fetch news feed (latest first)
$query = "SELECT * FROM news_feed ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$recent_news_feed = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Year filter for chart (default current year, clamp to last 10 years)
$currentYear = (int)date('Y');
$selectedYear = isset($_GET['year']) ? (int)$_GET['year'] : $currentYear;
if ($selectedYear < $currentYear - 10 || $selectedYear > $currentYear) {
    $selectedYear = $currentYear;
}
$availableYears = [];
for ($y = $currentYear; $y >= $currentYear - 10; $y--) { $availableYears[] = $y; }

// Build 12-month trends for Members and Events for selected year
$monthLabels = [];
$memberTrend = [];
$eventTrend = [];
for ($m = 1; $m <= 12; $m++) {
    $label = DateTime::createFromFormat('!m', (string)$m)->format('M') . ' ' . $selectedYear;
    $monthKey = sprintf('%04d-%02d', $selectedYear, $m);
    $monthLabels[] = $label;
    // Members by created_at month
    $stmt = $db->prepare("SELECT COUNT(*) AS total FROM membership_monitoring WHERE DATE_FORMAT(created_at, '%Y-%m') = ?");
    $stmt->execute([$monthKey]);
    $memberTrend[] = (int)($stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0);
    // Events by event_date month
    $stmt = $db->prepare("SELECT COUNT(*) AS total FROM events WHERE DATE_FORMAT(event_date, '%Y-%m') = ?");
    $stmt->execute([$monthKey]);
    $eventTrend[] = (int)($stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Membership System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/dashboard.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include __DIR__ . '/includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Members
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['total_members']; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Total Events
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['total_events']; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Upcoming Events
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['upcoming_events']; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Today's Attendance
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['today_attendance']; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- System Health Monitor -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            System Health Monitor
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <span id="systemStatus" class="badge fs-6">
                                                <i class="fas fa-heartbeat me-1"></i>
                                                <span id="statusText">Checking...</span>
                                            </span>
                                        </div>
                                        <div class="text-muted small mt-1">
                                            <i class="fas fa-shield-alt me-1"></i>
                                            <span id="statusDescription">Monitoring system performance</span>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <div id="temperatureIcon" class="text-center">
                                            <i class="fas fa-server fa-3x text-muted"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Moving Graph: Members vs Events (last 12 months) -->
                <div class="card mb-4">
                    <div class="card-header py-2 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-chart-line me-2"></i>Members and Events (<?php echo $selectedYear; ?>)</h6>
                        <form method="GET" class="d-flex align-items-center" id="chartYearForm">
                            <label class="me-2 mb-0 small text-muted">Year</label>
                            <select class="form-select form-select-sm" name="year" onchange="document.getElementById('chartYearForm').submit()">
                                <?php foreach ($availableYears as $y): ?>
                                    <option value="<?php echo $y; ?>" <?php echo ($y === $selectedYear) ? 'selected' : ''; ?>><?php echo $y; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </form>
                    </div>
                    <div class="card-body">
                        <canvas id="membersEventsChart" height="90"></canvas>
                    </div>
                </div>

                <!-- Content Row -->
                <div class="row">
                    <!-- Recent Announcements -->
                    <div class="col-lg-6 mb-4">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 font-weight-bold text-primary">
                                    <i class="fas fa-bullhorn me-2"></i>Recent Announcements
                                </h6>
                                <a href="announcements/index.php" class="btn btn-sm btn-primary">View All</a>
                            </div>
                            <div class="card-body">
                                <?php if (empty($recent_announcements)): ?>
                                    <p class="text-muted">No announcements yet.</p>
                                <?php else: ?>
                                    <?php foreach ($recent_announcements as $announcement): ?>
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="flex-shrink-0">
                                                <i class="fas fa-bullhorn text-primary"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($announcement['title']); ?></h6>
                                                <small class="text-muted">
                                                    <?php echo date('M d, Y', strtotime($announcement['created_at'])); ?>
                                                </small>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Events -->
                    <div class="col-lg-6 mb-4">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 font-weight-bold text-primary">
                                    <i class="fas fa-calendar me-2"></i>Recent Events
                                </h6>
                                <a href="events/index.php" class="btn btn-sm btn-primary">View All</a>
                            </div>
                            <div class="card-body">
                                <?php if (empty($recent_events)): ?>
                                    <p class="text-muted">No events yet.</p>
                                <?php else: ?>
                                    <?php foreach ($recent_events as $event): ?>
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="flex-shrink-0">
                                                <i class="fas fa-calendar-alt text-success"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($event['name']); ?></h6>
                                                <small class="text-muted">
                                                    <?php echo date('M d, Y', strtotime($event['event_date'])); ?> - 
                                                    <?php echo ucfirst($event['status']); ?>
                                                </small>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>


    <!-- Documentation / News Feed -->
<div class="col-lg-9 col-md-10 mx-auto mb-4">
    <div class="card shadow-sm mb-4" style="max-width: 1200px; left: 115px;">
        <div class="card-header py-2 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">
                <i class="fas fa-newspaper me-2"></i>Media Feed
            </h6>

            <div class="d-flex align-items-center">
                <button type="button" id="toggleSort" class="btn btn-sm btn-outline-secondary me-2" data-state="latest">
                    <i class="fas fa-sort-amount-down"></i> Latest
                </button>
                <a href="news_feed/add.php" class="btn btn-sm btn-primary">Add New</a>
            </div>


        </div>
        <div class="card-body">
            <?php if (isset($_GET['deleted'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>News deleted successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (empty($recent_news_feed)): ?>
                <p class="text-muted">No posts yet.</p>
            <?php else: ?>
                <div id="news-feed-list">
                <?php foreach ($recent_news_feed as $news): ?>
                    <div class="mb-3 border-bottom pb-2" data-created-at="<?php echo strtotime($news['created_at']); ?>">
    <h6 class="mb-1"><?php echo htmlspecialchars($news['title']); ?></h6>
    <p class="small"><?php echo nl2br(htmlspecialchars($news['description'])); ?></p>

    <?php if ($news['media_type'] === 'image'): ?>
        <img src="../uploads/<?php echo htmlspecialchars($news['media_path']); ?>" 
             class="img-fluid rounded mb-2 d-block mx-auto" 
             style="max-width:720px; max-height:530px; object-fit:cover;">
    <?php elseif ($news['media_type'] === 'video'): ?>
        <video controls 
               class="d-block mx-auto mb-2" 
               style="max-width:720px; max-height:530px; border-radius:6px;">
            <source src="../uploads/<?php echo htmlspecialchars($news['media_path']); ?>" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center">
        <small class="text-muted">
            <?php echo date('M d, Y', strtotime($news['created_at'])); ?>
        </small>

        <div>
            <a href="news_feed/edit.php?id=<?php echo $news['id']; ?>" 
               class="text-decoration-none text-primary me-3">
               <i class="fas fa-edit"></i> Edit
            </a>
            <a href="?action=delete&id=<?php echo $news['id']; ?>" 
               class="text-decoration-none text-primary" 
               onclick="return confirm('Are you sure you want to delete this post?');">
               <i class="fas fa-trash"></i> Delete
            </a>
        </div>
    </div>
    </div>

                <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>




    <script>
    (function() {
        var toggleBtn = document.getElementById('toggleSort');
        var list = document.getElementById('news-feed-list');
        if (!toggleBtn || !list) return;

        function sortItems(order) {
            var items = Array.prototype.slice.call(list.children);
            items.sort(function(a, b) {
                var at = parseInt(a.getAttribute('data-created-at') || '0', 10);
                var bt = parseInt(b.getAttribute('data-created-at') || '0', 10);
                return order === 'latest' ? (bt - at) : (at - bt);
            });
            items.forEach(function(el) { list.appendChild(el); });
        }

        toggleBtn.addEventListener('click', function() {
            var state = toggleBtn.getAttribute('data-state');
            var next = state === 'latest' ? 'oldest' : 'latest';
            toggleBtn.setAttribute('data-state', next);
            toggleBtn.innerHTML = next === 'latest'
                ? '<i class="fas fa-sort-amount-down"></i> Latest'
                : '<i class="fas fa-sort-amount-up"></i> Oldest';
            sortItems(next);
        });

        // Ensure initial ordering is latest
        sortItems('latest');
    })();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    (function(){
        var ctx = document.getElementById('membersEventsChart');
        if (!ctx) return;
        var labels = <?php echo json_encode($monthLabels); ?>;
        var members = <?php echo json_encode($memberTrend); ?>;
        var events = <?php echo json_encode($eventTrend); ?>;
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Members',
                        data: members,
                        borderColor: 'rgba(54, 162, 235, 1)',
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        tension: 0.35,
                        fill: true,
                        pointRadius: 3
                    },
                    {
                        label: 'Events',
                        data: events,
                        borderColor: 'rgba(255, 99, 132, 1)',
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        tension: 0.35,
                        fill: true,
                        pointRadius: 3
                    }
                ]
            },
            options: {
                responsive: true,
                animation: {
                    duration: 900,
                    easing: 'easeInOutQuart'
                },
                interaction: { mode: 'index', intersect: false },
                stacked: false,
                plugins: {
                    legend: { display: true },
                    tooltip: { enabled: true }
                },
                scales: {
                    y: { beginAtZero: true, ticks: { precision: 0 } }
                }
            }
        });
    })();

    // System Health Monitoring
    (function() {
        var statusElement = document.getElementById('systemStatus');
        var statusText = document.getElementById('statusText');
        var statusDescription = document.getElementById('statusDescription');
        var temperatureIcon = document.getElementById('temperatureIcon');
        
        if (!statusElement || !statusText || !statusDescription || !temperatureIcon) return;

        // Simulate system health monitoring
        function updateSystemStatus() {
            // Simulate random system performance metrics
            var cpuUsage = Math.floor(Math.random() * 100);
            var memoryUsage = Math.floor(Math.random() * 100);
            var status, badgeClass, iconClass, description;
            
            if (cpuUsage < 30 && memoryUsage < 50) {
                status = 'Excellent';
                badgeClass = 'bg-success';
                iconClass = 'fas fa-server';
                description = 'System running optimally (CPU: ' + cpuUsage + '%, RAM: ' + memoryUsage + '%)';
            } else if (cpuUsage < 70 && memoryUsage < 80) {
                status = 'Good';
                badgeClass = 'bg-info';
                iconClass = 'fas fa-server';
                description = 'System performance is good (CPU: ' + cpuUsage + '%, RAM: ' + memoryUsage + '%)';
            } else {
                status = 'Warning';
                badgeClass = 'bg-warning';
                iconClass = 'fas fa-server';
                description = 'System under load (CPU: ' + cpuUsage + '%, RAM: ' + memoryUsage + '%)';
            }
            
            // Update status badge
            statusElement.className = 'badge fs-6 ' + badgeClass;
            statusText.textContent = status;
            
            // Update description
            statusDescription.textContent = description;
            
            // Update icon with animation
            temperatureIcon.innerHTML = '<i class="' + iconClass + ' fa-3x text-muted system-status-icon"></i>';
            
            // Add pulse animation for warning status
            if (status === 'Warning') {
                temperatureIcon.querySelector('.system-status-icon').style.animation = 'pulse 2s infinite';
            } else {
                temperatureIcon.querySelector('.system-status-icon').style.animation = 'none';
            }
        }
        
        // Initial update
        updateSystemStatus();
        
        // Update every 15 seconds
        setInterval(updateSystemStatus, 15000);
    })();
    </script>
    
    <style>
    @keyframes pulse {
        0% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.1); opacity: 0.8; }
        100% { transform: scale(1); opacity: 1; }
    }
    
    .system-status-icon {
        transition: all 0.3s ease;
    }
    
    .border-left-info {
        border-left: 0.25rem solid #17a2b8 !important;
    }
    
    .text-info {
        color: #17a2b8 !important;
    }
    </style>
</body>
</html>
