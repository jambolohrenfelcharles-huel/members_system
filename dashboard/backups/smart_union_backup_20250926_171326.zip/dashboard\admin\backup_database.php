<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    http_response_code(403);
    echo 'Forbidden';
    exit();
}
// Ensure backup directory
$backupDir = realpath(__DIR__ . '/..') . DIRECTORY_SEPARATOR . 'backups';
if ($backupDir === false) {
    $backupDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'backups';
}
if (!is_dir($backupDir)) {
    @mkdir($backupDir, 0775, true);
}

// Create a ZIP of the entire project directory (one level above dashboard)
$timestamp = date('Ymd_His');
$zipPath = $backupDir . DIRECTORY_SEPARATOR . 'system_backup_' . $timestamp . '.zip';
$zip = new ZipArchive();
if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    http_response_code(500);
    echo 'Failed to create ZIP';
    exit();
}

// Base directory for the whole system (two levels up from this file)
$baseDir = realpath(__DIR__ . '/..' . '/..');
if ($baseDir === false) { $baseDir = dirname(__DIR__, 2); }

// Exclude backups and exports to avoid recursion and huge files
$excludeDirs = [
    DIRECTORY_SEPARATOR . 'dashboard' . DIRECTORY_SEPARATOR . 'backups',
    DIRECTORY_SEPARATOR . 'dashboard' . DIRECTORY_SEPARATOR . 'exports',
    DIRECTORY_SEPARATOR . '.git',
];

$baseLen = strlen($baseDir) + 1;
$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($baseDir, FilesystemIterator::SKIP_DOTS),
    RecursiveIteratorIterator::SELF_FIRST
);

foreach ($iterator as $file) {
    $path = $file->getPathname();
    $rel = substr($path, $baseLen);
    $skip = false;
    foreach ($excludeDirs as $ex) {
        if (strpos($path, $baseDir . $ex) === 0) { $skip = true; break; }
    }
    if ($skip) continue;

    if ($file->isDir()) {
        $zip->addEmptyDir($rel);
    } else {
        $zip->addFile($path, $rel);
    }
}

$zip->close();

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . basename($zipPath) . '"');
header('Content-Length: ' . filesize($zipPath));
readfile($zipPath);
exit();
?>
