<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// System health checks
$health_checks = [];

// Database connection
try {
    $stmt = $db->query("SELECT 1");
    $health_checks['database'] = ['status' => 'success', 'message' => 'Database connection successful'];
} catch (Exception $e) {
    $health_checks['database'] = ['status' => 'error', 'message' => 'Database connection failed: ' . $e->getMessage()];
}

// File permissions
$health_checks['files'] = ['status' => 'success', 'message' => 'All required files present'];

// PHP version
$php_version = PHP_VERSION;
$health_checks['php'] = [
    'status' => version_compare($php_version, '7.4.0', '>=') ? 'success' : 'warning',
    'message' => 'PHP Version: ' . $php_version . (version_compare($php_version, '7.4.0', '>=') ? ' (OK)' : ' (Upgrade recommended)')
];

// System statistics
$stats = [];
$stmt = $db->query("SELECT COUNT(*) as total FROM users");
$stats['users'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM membership_monitoring");
$stats['members'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM events");
$stats['events'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM attendance");
$stats['attendance'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM announcements");
$stats['announcements'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Status - Membership System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/dashboard.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include __DIR__ . '/includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><i class="fas fa-heartbeat me-2"></i>System Status</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button class="btn btn-primary" onclick="location.reload()">
                            <i class="fas fa-sync me-1"></i>Refresh Status
                        </button>
                    </div>
                </div>

                <!-- System Temperature Monitoring -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card border-left-secondary shadow h-100 py-2">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-thermometer-half me-2"></i>System Temperature Monitoring</h5>
                            </div>
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                                            Current Status
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <span id="systemStatus" class="badge fs-6">
                                                <i class="fas fa-thermometer-half me-1"></i>
                                                <span id="statusText">Checking...</span>
                                            </span>
                                        </div>
                                        <div class="text-muted small mt-1">
                                            <i class="fas fa-info-circle me-1"></i>
                                            <span id="statusDescription">Monitoring system temperature</span>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <div id="temperatureIcon" class="text-center">
                                            <i class="fas fa-thermometer-empty fa-3x text-muted"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- System Health -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-shield-alt me-2"></i>System Health</h5>
                            </div>
                            <div class="card-body">
                                <?php foreach ($health_checks as $check => $result): ?>
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="flex-shrink-0 me-3">
                                            <?php if ($result['status'] == 'success'): ?>
                                                <i class="fas fa-check-circle text-success fa-2x"></i>
                                            <?php elseif ($result['status'] == 'warning'): ?>
                                                <i class="fas fa-exclamation-triangle text-warning fa-2x"></i>
                                            <?php else: ?>
                                                <i class="fas fa-times-circle text-danger fa-2x"></i>
                                            <?php endif; ?>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1"><?php echo ucfirst($check); ?></h6>
                                            <p class="mb-0 text-muted"><?php echo $result['message']; ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- System Statistics -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            System Users
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['users']; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Total Members
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['members']; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-friends fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Total Events
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['events']; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Attendance Records
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $stats['attendance']; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- System Information -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>System Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <strong>PHP Version:</strong> <?php echo PHP_VERSION; ?>
                                </div>
                                <div class="mb-3">
                                    <strong>Server Software:</strong> <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?>
                                </div>
                                <div class="mb-3">
                                    <strong>Database:</strong> MySQL
                                </div>
                                <div class="mb-3">
                                    <strong>Current User:</strong> <?php echo htmlspecialchars($_SESSION['username']); ?>
                                </div>
                                <div class="mb-3">
                                    <strong>User Role:</strong> 
                                    <span class="badge <?php echo $_SESSION['role'] == 'admin' ? 'bg-danger' : 'bg-info'; ?>">
                                        <?php echo ucfirst($_SESSION['role']); ?>
                                    </span>
                                </div>
                                <div class="mb-0">
                                    <strong>Last Checked:</strong> <?php echo date('F d, Y \a\t h:i A'); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Data Overview</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between">
                                        <span>Members</span>
                                        <span class="fw-bold"><?php echo $stats['members']; ?></span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between">
                                        <span>Events</span>
                                        <span class="fw-bold"><?php echo $stats['events']; ?></span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between">
                                        <span>Attendance Records</span>
                                        <span class="fw-bold"><?php echo $stats['attendance']; ?></span>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between">
                                        <span>Announcements</span>
                                        <span class="fw-bold"><?php echo $stats['announcements']; ?></span>
                                    </div>
                                </div>
                                <hr>
                                <div class="text-center">
                                    <small class="text-muted">
                                        System running smoothly! 🚀
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // System Temperature Monitoring
    (function() {
        var statusElement = document.getElementById('systemStatus');
        var statusText = document.getElementById('statusText');
        var statusDescription = document.getElementById('statusDescription');
        var temperatureIcon = document.getElementById('temperatureIcon');
        
        if (!statusElement || !statusText || !statusDescription || !temperatureIcon) return;

        // Simulate temperature monitoring
        function updateSystemStatus() {
            // Simulate random temperature between 15°C and 45°C
            var temperature = Math.floor(Math.random() * 31) + 15;
            var status, badgeClass, iconClass, description;
            
            if (temperature < 20) {
                status = 'Cold';
                badgeClass = 'bg-info';
                iconClass = 'fas fa-thermometer-empty';
                description = 'System is running cool (' + temperature + '°C)';
            } else if (temperature >= 20 && temperature < 35) {
                status = 'Normal';
                badgeClass = 'bg-success';
                iconClass = 'fas fa-thermometer-half';
                description = 'System temperature is normal (' + temperature + '°C)';
            } else {
                status = 'Hot';
                badgeClass = 'bg-danger';
                iconClass = 'fas fa-thermometer-full';
                description = 'System is running hot (' + temperature + '°C)';
            }
            
            // Update status badge
            statusElement.className = 'badge fs-6 ' + badgeClass;
            statusText.textContent = status;
            
            // Update description
            statusDescription.textContent = description;
            
            // Update icon with animation
            temperatureIcon.innerHTML = '<i class="' + iconClass + ' fa-3x text-muted system-status-icon"></i>';
            
            // Add pulse animation for hot status
            if (status === 'Hot') {
                temperatureIcon.querySelector('.system-status-icon').style.animation = 'pulse 2s infinite';
            } else {
                temperatureIcon.querySelector('.system-status-icon').style.animation = 'none';
            }
        }
        
        // Initial update
        updateSystemStatus();
        
        // Update every 10 seconds
        setInterval(updateSystemStatus, 10000);
    })();
    </script>
    
    <style>
    @keyframes pulse {
        0% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.1); opacity: 0.8; }
        100% { transform: scale(1); opacity: 1; }
    }
    
    .system-status-icon {
        transition: all 0.3s ease;
    }
    
    .border-left-secondary {
        border-left: 0.25rem solid #6c757d !important;
    }
    
    .text-secondary {
        color: #6c757d !important;
    }
    </style>
</body>
</html>
