<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../auth/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

$errors = [];
$success = '';

if ($_POST) {
    $member_id = trim($_POST['member_id']);
    $full_name = trim($_POST['full_name']);
    $club_position = trim($_POST['club_position']);
    
    // Validation
    if (empty($member_id)) $errors[] = "Member ID is required";
    if (empty($full_name)) $errors[] = "Full name is required";
    if (empty($club_position)) $errors[] = "Club position is required";
    
    // Check if member already marked attendance today
    if (empty($errors)) {
        $stmt = $db->prepare("SELECT id FROM attendance WHERE member_id = ? AND DATE(date) = CURDATE()");
        $stmt->execute([$member_id]);
        if ($stmt->fetch()) {
            $errors[] = "This member has already marked attendance today";
        }
    }
    
    if (empty($errors)) {
        $query = "INSERT INTO attendance (member_id, full_name, club_position) VALUES (?, ?, ?)";
        
        $stmt = $db->prepare($query);
        $result = $stmt->execute([$member_id, $full_name, $club_position]);
        
        if ($result) {
            header('Location: index.php?added=1');
            exit();
        } else {
            $errors[] = "Failed to mark attendance";
        }
    }
}

// Get all members for autocomplete
$stmt = $db->query("SELECT id, name, club_position FROM membership_monitoring ORDER BY name");
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Attendance - Membership System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/dashboard.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include __DIR__ . '/../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><i class="fas fa-check-circle me-2"></i>Mark Attendance</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                      
                    </div>
                </div>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger" role="alert">
                        <h6><i class="fas fa-exclamation-triangle me-2"></i>Please fix the following errors:</h6>
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-check-circle me-2"></i>Mark Attendance</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" id="attendanceForm">
                                    <div class="mb-3">
                                        <label for="member_id" class="form-label">Member ID *</label>
                                        <input type="text" class="form-control" id="member_id" name="member_id" value="<?php echo isset($_POST['member_id']) ? htmlspecialchars($_POST['member_id']) : ''; ?>" required>
                                        <div class="form-text">Enter the member's ID number</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="full_name" class="form-label">Full Name *</label>
                                        <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="club_position" class="form-label">Club Position *</label>
                                        <select class="form-select" id="club_position" name="club_position" required>
                                            <option value="">Select Position</option>
                                            <option value="President / Worthy President" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'President / Worthy President') ? 'selected' : ''; ?>>President / Worthy President</option>
                                            <option value="Vice President / Worthy Vice President" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Vice President / Worthy Vice President') ? 'selected' : ''; ?>>Vice President / Worthy Vice President</option>
                                            <option value="Secretary / Worthy Secretary" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Secretary / Worthy Secretary') ? 'selected' : ''; ?>>Secretary / Worthy Secretary</option>
                                            <option value="Treasurer / Worthy Treasurer" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Treasurer / Worthy Treasurer') ? 'selected' : ''; ?>>Treasurer / Worthy Treasurer</option>
                                            <option value="Chaplain" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Chaplain') ? 'selected' : ''; ?>>Chaplain</option>
                                            <option value="Conductor" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Conductor') ? 'selected' : ''; ?>>Conductor</option>
                                            <option value="Inside Guard" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Inside Guard') ? 'selected' : ''; ?>>Inside Guard</option>
                                            <option value="Outside Guard" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Outside Guard') ? 'selected' : ''; ?>>Outside Guard</option>
                                            <option value="Trustees" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Trustees') ? 'selected' : ''; ?>>Trustees</option>
                                            <option value="Auditors" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Auditors') ? 'selected' : ''; ?>>Auditors</option>
                                            <option value="Marshal" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Marshal') ? 'selected' : ''; ?>>Marshal</option>
                                            <option value="Past President" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Past President') ? 'selected' : ''; ?>>Past President</option>
                                            <option value="President / Madam President" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'President / Madam President') ? 'selected' : ''; ?>>President / Madam President</option>
                                            <option value="Vice President / Madam Vice President" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Vice President / Madam Vice President') ? 'selected' : ''; ?>>Vice President / Madam Vice President</option>
                                            <option value="Secretary / Madam Secretary" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Secretary / Madam Secretary') ? 'selected' : ''; ?>>Secretary / Madam Secretary</option>
                                            <option value="Treasurer / Madam Treasurer" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Treasurer / Madam Treasurer') ? 'selected' : ''; ?>>Treasurer / Madam Treasurer</option>
                                            <option value="Chaplain / Madam Chaplain" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Chaplain / Madam Chaplain') ? 'selected' : ''; ?>>Chaplain / Madam Chaplain</option>
                                            <option value="Conductor / Madam Conductor" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Conductor / Madam Conductor') ? 'selected' : ''; ?>>Conductor / Madam Conductor</option>
                                            <option value="Inside Guard / Madam Inside Guard" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Inside Guard / Madam Inside Guard') ? 'selected' : ''; ?>>Inside Guard / Madam Inside Guard</option>
                                            <option value="Outside Guard / Madam Outside Guard" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Outside Guard / Madam Outside Guard') ? 'selected' : ''; ?>>Outside Guard / Madam Outside Guard</option>
                                            <option value="Trustees / Auditors" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Trustees / Auditors') ? 'selected' : ''; ?>>Trustees / Auditors</option>
                                            <option value="Membership Chairman" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Membership Chairman') ? 'selected' : ''; ?>>Membership Chairman</option>
                                            <option value="Program/Activity Coordinator" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Program/Activity Coordinator') ? 'selected' : ''; ?>>Program/Activity Coordinator</option>
                                            <option value="Fraternal Committee Chairs" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Fraternal Committee Chairs') ? 'selected' : ''; ?>>Fraternal Committee Chairs</option>
                                            <option value="Member" <?php echo (isset($_POST['club_position']) && $_POST['club_position'] == 'Member') ? 'selected' : ''; ?>>Member</option>
                                        </select>
                                    </div>

                                    <div class="d-flex justify-content-end">
                                        <a href="index.php" class="btn btn-secondary me-2">Cancel</a>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-check me-1"></i>Mark Attendance
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-users me-2"></i>Available Members</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <input type="text" class="form-control" id="memberSearch" placeholder="Search members...">
                                </div>
                                <div class="member-list" style="max-height: 300px; overflow-y: auto;">
                                    <?php foreach ($members as $member): ?>
                                        <div class="member-item p-2 border-bottom cursor-pointer" 
                                             data-id="<?php echo $member['id']; ?>" 
                                             data-name="<?php echo htmlspecialchars($member['name']); ?>" 
                                             data-position="<?php echo htmlspecialchars($member['club_position']); ?>">
                                            <div class="fw-bold"><?php echo htmlspecialchars($member['name']); ?></div>
                                            <small class="text-muted">ID: <?php echo $member['id']; ?> | <?php echo htmlspecialchars($member['club_position']); ?></small>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>

                        <div class="card mt-3">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Quick Info</h5>
                            </div>
                            <div class="card-body">
                                <p class="mb-2"><strong>Today's Date:</strong> <?php echo date('M d, Y'); ?></p>
                                <p class="mb-2"><strong>Current Time:</strong> <?php echo date('h:i A'); ?></p>
                                <p class="mb-0"><strong>Note:</strong> Each member can only mark attendance once per day.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Member search functionality
        document.getElementById('memberSearch').addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const memberItems = document.querySelectorAll('.member-item');
            
            memberItems.forEach(item => {
                const name = item.dataset.name.toLowerCase();
                const id = item.dataset.id;
                
                if (name.includes(searchTerm) || id.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });

        // Member selection functionality
        document.querySelectorAll('.member-item').forEach(item => {
            item.addEventListener('click', function() {
                document.getElementById('member_id').value = this.dataset.id;
                document.getElementById('full_name').value = this.dataset.name;
                document.getElementById('club_position').value = this.dataset.position;
            });
        });

        // Add cursor pointer style
        document.querySelectorAll('.member-item').forEach(item => {
            item.style.cursor = 'pointer';
        });
    </script>
    <style>
        .member-item:hover {
            background-color: #f8f9fa;
        }
        .cursor-pointer {
            cursor: pointer;
        }
    </style>
</body>
</html>
