<?php
// Determine base path relative to dashboard root regardless of current depth
$scriptDir = dirname($_SERVER['PHP_SELF']);
$base_path = '';
if (($pos = strpos($scriptDir, '/dashboard')) !== false) {
	$after = substr($scriptDir, $pos + strlen('/dashboard'));
	$afterTrim = trim($after, '/');
	$depth = $afterTrim === '' ? 0 : (substr_count($afterTrim, '/') + 1);
	$base_path = str_repeat('../', $depth);
} else {
	$base_path = '';
}

// Compute active section based on current path
$path = $_SERVER['PHP_SELF'];
$isDashboard = basename($path) === 'index.php' && strpos($path, '/dashboard/') !== false && !preg_match('#/dashboard/.+/#', $path);
$isMembers = strpos($path, '/dashboard/members/') !== false;
$isEvents = strpos($path, '/dashboard/events/') !== false;
$isAttendance = strpos($path, '/dashboard/attendance/') !== false;
$isAnnouncements = strpos($path, '/dashboard/announcements/') !== false;
$isReports = strpos($path, '/dashboard/reports/') !== false;
$isSystemStatus = strpos($path, '/dashboard/system_status.php') !== false;
$isAdmin = strpos($path, '/dashboard/admin/') !== false;
?>
<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse pt-0">
    <div class="px-3 pt-2 pb-2 mb-2">
        <div>
           
            <div id="sidebar-local-datetime" class="fw-bold"></div>
        </div>
    </div>
    <div class="position-sticky pt-0">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo $isDashboard ? 'active' : ''; ?>" href="<?php echo $base_path; ?>index.php">
                    <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $isMembers ? 'active' : ''; ?>" href="<?php echo $base_path; ?>members/index.php">
                    <i class="fas fa-users me-2"></i>Members
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $isEvents ? 'active' : ''; ?>" href="<?php echo $base_path; ?>events/index.php">
                    <i class="fas fa-calendar me-2"></i>Events
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $isAttendance ? 'active' : ''; ?>" href="<?php echo $base_path; ?>attendance/index.php">
                    <i class="fas fa-check-circle me-2"></i>Attendance
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $isAnnouncements ? 'active' : ''; ?>" href="<?php echo $base_path; ?>announcements/index.php">
                    <i class="fas fa-bullhorn me-2"></i>Announcements
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $isReports ? 'active' : ''; ?>" href="<?php echo $base_path; ?>reports/index.php">
                    <i class="fas fa-chart-bar me-2"></i>Reports
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $isSystemStatus ? 'active' : ''; ?>" href="<?php echo $base_path; ?>system_status.php">
                    <i class="fas fa-heartbeat me-2"></i>System Status
                </a>
            </li>
            <?php if ($_SESSION['role'] == 'admin'): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo $isAdmin ? 'active' : ''; ?>" href="<?php echo $base_path; ?>admin/index.php">
                    <i class="fas fa-cog me-2"></i>Admin Panel
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<script>
(function(){
    function updateSidebarClock(){
        var el = document.getElementById('sidebar-local-datetime');
        if(!el) return;
        var now = new Date();
        try {
            var formatter = new Intl.DateTimeFormat(navigator.language || 'en-US', {
                dateStyle: 'long',
                timeStyle: 'short'
            });
            el.innerHTML = '<i class="far fa-clock me-2"></i>' + formatter.format(now);
        } catch (e) {
            el.innerHTML = '<i class="far fa-clock me-2"></i>' + now.toLocaleString();
        }
    }
    updateSidebarClock();
    setInterval(updateSidebarClock, 30000);
})();
</script>
