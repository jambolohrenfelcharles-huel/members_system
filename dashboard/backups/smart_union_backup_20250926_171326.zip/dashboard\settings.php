<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

$success = '';
$errors = [];
$activeTab = $_GET['tab'] ?? 'security';

// Handle form submissions
if ($_POST) {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'update_account') {
        $new_username = isset($_POST['username']) ? trim($_POST['username']) : '';

        if ($new_username === '') {
            $errors[] = "Username is required";
        } else {
            $check = $db->prepare("SELECT id FROM users WHERE username = ? AND id <> ? LIMIT 1");
            $check->execute([$new_username, $_SESSION['user_id']]);
            if ($check->fetch(PDO::FETCH_ASSOC)) {
                $errors[] = "Username is already taken";
            }
        }

        if (empty($errors)) {
            $stmt = $db->prepare("UPDATE users SET username = ? WHERE id = ?");
            $result = $stmt->execute([$new_username, $_SESSION['user_id']]);
            if ($result) {
                $_SESSION['username'] = $new_username;
                $success = "Account information updated successfully!";
                $activeTab = 'security';
                // refresh current user data
                $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$_SESSION['user_id']]);
                $current_user = $stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                $errors[] = "Failed to update account information.";
            }
        } else {
            $activeTab = 'security';
        }
    } elseif ($action == 'update_notifications') {
        $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
        $event_reminders = isset($_POST['event_reminders']) ? 1 : 0;
        $system_updates = isset($_POST['system_updates']) ? 1 : 0;
        
        // Store in session for demo purposes (in real app, store in database)
        $_SESSION['notifications'] = [
            'email_notifications' => $email_notifications,
            'event_reminders' => $event_reminders,
            'system_updates' => $system_updates
        ];
        
        $success = "Notification preferences updated!";
        $activeTab = 'notifications';
    } elseif ($action == 'update_system_config') {
        $site_name = trim($_POST['site_name'] ?? '');
        $timezone = $_POST['timezone'] ?? '';
        $date_format = $_POST['date_format'] ?? '';
        $items_per_page = (int)($_POST['items_per_page'] ?? 10);
        
        if (empty($site_name)) $errors[] = "Site name is required";
        if ($items_per_page < 5 || $items_per_page > 100) $errors[] = "Items per page must be between 5 and 100";
        
        if (empty($errors)) {
            // Store in session for demo purposes (in real app, store in database)
            $_SESSION['system_config'] = [
                'site_name' => $site_name,
                'timezone' => $timezone,
                'date_format' => $date_format,
                'items_per_page' => $items_per_page
            ];
            
            $success = "System configuration updated!";
            $activeTab = 'system';
        }
    } elseif ($action == 'clear_attendance') {
        $stmt = $db->prepare("DELETE FROM attendance");
        $result = $stmt->execute();
        
        if ($result) {
            $success = "All attendance records have been cleared.";
            $activeTab = 'tools';
        } else {
            $errors[] = "Failed to clear attendance records.";
        }
    } elseif ($action == 'clear_announcements') {
        $stmt = $db->prepare("DELETE FROM announcements");
        $result = $stmt->execute();
        
        if ($result) {
            $success = "All announcements have been cleared.";
            $activeTab = 'tools';
        } else {
            $errors[] = "Failed to clear announcements.";
        }
    } elseif ($action == 'backup_database') {
        // Simulate backup process
        $success = "Database backup completed successfully!";
        $activeTab = 'backup';
    }
}

// Get current user data
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$current_user = $stmt->fetch(PDO::FETCH_ASSOC);

// Get system statistics
$stats = [];
$stmt = $db->query("SELECT COUNT(*) as total FROM membership_monitoring");
$stats['total_members'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM events");
$stats['total_events'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM attendance");
$stats['total_attendance'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM announcements");
$stats['total_announcements'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Get notification preferences (default values)
$notifications = $_SESSION['notifications'] ?? [
    'email_notifications' => 1,
    'event_reminders' => 1,
    'system_updates' => 0
];

// Get system configuration (default values)
$system_config = $_SESSION['system_config'] ?? [
    'site_name' => 'SmartUnion',
    'timezone' => 'Asia/Manila',
    'date_format' => 'Y-m-d',
    'items_per_page' => 10
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Membership System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/dashboard.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include __DIR__ . '/includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><i class="fas fa-cog me-2"></i>Settings</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="exportSettings()">
                                <i class="fas fa-download me-1"></i>Export Settings
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="resetSettings()">
                                <i class="fas fa-undo me-1"></i>Reset to Default
                            </button>
                        </div>
                    </div>
                </div>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <h6><i class="fas fa-exclamation-triangle me-2"></i>Please fix the following errors:</h6>
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Settings Navigation -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <ul class="nav nav-pills nav-fill" id="settingsTabs" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link <?php echo $activeTab === 'security' ? 'active' : ''; ?>" 
                                                id="security-tab" data-bs-toggle="pill" data-bs-target="#security" 
                                                type="button" role="tab">
                                            <i class="fas fa-shield-alt me-2"></i>Security
                                        </button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link <?php echo $activeTab === 'notifications' ? 'active' : ''; ?>" 
                                                id="notifications-tab" data-bs-toggle="pill" data-bs-target="#notifications" 
                                                type="button" role="tab">
                                            <i class="fas fa-bell me-2"></i>Notifications
                                        </button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link <?php echo $activeTab === 'system' ? 'active' : ''; ?>" 
                                                id="system-tab" data-bs-toggle="pill" data-bs-target="#system" 
                                                type="button" role="tab">
                                            <i class="fas fa-cogs me-2"></i>System
                                        </button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link <?php echo $activeTab === 'backup' ? 'active' : ''; ?>" 
                                                id="backup-tab" data-bs-toggle="pill" data-bs-target="#backup" 
                                                type="button" role="tab">
                                            <i class="fas fa-database me-2"></i>Backup
                                        </button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link <?php echo $activeTab === 'tools' ? 'active' : ''; ?>" 
                                                id="tools-tab" data-bs-toggle="pill" data-bs-target="#tools" 
                                                type="button" role="tab">
                                            <i class="fas fa-tools me-2"></i>Tools
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Settings Content -->
                <div class="tab-content" id="settingsTabContent">

                    <!-- Security Settings -->
                    <div class="tab-pane fade <?php echo $activeTab === 'security' ? 'show active' : ''; ?>" 
                         id="security" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="card mb-3">
                                    <div class="card-header">
                                        <h5 class="mb-0"><i class="fas fa-user me-2"></i>Account Information</h5>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST">
                                            <input type="hidden" name="action" value="update_account">
                                            <div class="mb-3">
                                                <label for="username" class="form-label">Username *</label>
                                                <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($current_user['username'] ?? ''); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Role</label>
                                                <p class="form-control-plaintext">
                                                    <span class="badge <?php echo ($current_user['role'] ?? '') === 'admin' ? 'bg-danger' : 'bg-info'; ?>">
                                                        <?php echo isset($current_user['role']) ? ucfirst($current_user['role']) : 'User'; ?>
                                                    </span>
                                                </p>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Account Created</label>
                                                <p class="form-control-plaintext"><?php echo isset($current_user['created_at']) ? date('F d, Y \a\t h:i A', strtotime($current_user['created_at'])) : '-'; ?></p>
                                            </div>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-save me-1"></i>Save Changes
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0"><i class="fas fa-shield-alt me-2"></i>Security Status</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Password Strength</span>
                                                <span id="password-strength" class="badge bg-danger">Very Weak</span>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Two-Factor Auth</span>
                                                <span class="badge bg-warning">Disabled</span>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Last Login</span>
                                                <small class="text-muted"><?php echo date('M d, Y'); ?></small>
                                            </div>
                                        </div>
                                        <div class="mb-0">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Login Attempts</span>
                                                <span class="badge bg-info">0 Failed</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Notification Settings -->
                    <div class="tab-pane fade <?php echo $activeTab === 'notifications' ? 'show active' : ''; ?>" 
                         id="notifications" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0"><i class="fas fa-bell me-2"></i>Notification Preferences</h5>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST">
                                            <input type="hidden" name="action" value="update_notifications">
                                            <div class="mb-4">
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" id="email_notifications" 
                                                           name="email_notifications" <?php echo $notifications['email_notifications'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label" for="email_notifications">
                                                        <strong>Email Notifications</strong>
                                                        <p class="text-muted small mb-0">Receive notifications via email</p>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="mb-4">
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" id="event_reminders" 
                                                           name="event_reminders" <?php echo $notifications['event_reminders'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label" for="event_reminders">
                                                        <strong>Event Reminders</strong>
                                                        <p class="text-muted small mb-0">Get reminded about upcoming events</p>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="mb-4">
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" id="system_updates" 
                                                           name="system_updates" <?php echo $notifications['system_updates'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label" for="system_updates">
                                                        <strong>System Updates</strong>
                                                        <p class="text-muted small mb-0">Notifications about system maintenance</p>
                                                    </label>
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-save me-1"></i>Save Preferences
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0"><i class="fas fa-envelope me-2"></i>Email Settings</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <label class="form-label">Email Frequency</label>
                                            <select class="form-select">
                                                <option>Immediate</option>
                                                <option>Daily Digest</option>
                                                <option>Weekly Summary</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Quiet Hours</label>
                                            <div class="row">
                                                <div class="col-6">
                                                    <input type="time" class="form-control" value="22:00">
                                                </div>
                                                <div class="col-6">
                                                    <input type="time" class="form-control" value="08:00">
                                                </div>
                                            </div>
                                        </div>
                                        <button type="button" class="btn btn-outline-secondary btn-sm">
                                            <i class="fas fa-paper-plane me-1"></i>Test Email
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- System Settings -->
                    <div class="tab-pane fade <?php echo $activeTab === 'system' ? 'show active' : ''; ?>" 
                         id="system" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0"><i class="fas fa-cogs me-2"></i>System Configuration</h5>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST">
                                            <input type="hidden" name="action" value="update_system_config">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="site_name" class="form-label">Site Name *</label>
                                                        <input type="text" class="form-control" id="site_name" name="site_name" 
                                                               value="<?php echo htmlspecialchars($system_config['site_name']); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="timezone" class="form-label">Timezone</label>
                                                        <select class="form-select" id="timezone" name="timezone">
                                                            <option value="Asia/Manila" <?php echo $system_config['timezone'] === 'Asia/Manila' ? 'selected' : ''; ?>>Asia/Manila</option>
                                                            <option value="UTC" <?php echo $system_config['timezone'] === 'UTC' ? 'selected' : ''; ?>>UTC</option>
                                                            <option value="America/New_York" <?php echo $system_config['timezone'] === 'America/New_York' ? 'selected' : ''; ?>>America/New_York</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="date_format" class="form-label">Date Format</label>
                                                        <select class="form-select" id="date_format" name="date_format">
                                                            <option value="Y-m-d" <?php echo $system_config['date_format'] === 'Y-m-d' ? 'selected' : ''; ?>>YYYY-MM-DD</option>
                                                            <option value="m/d/Y" <?php echo $system_config['date_format'] === 'm/d/Y' ? 'selected' : ''; ?>>MM/DD/YYYY</option>
                                                            <option value="d/m/Y" <?php echo $system_config['date_format'] === 'd/m/Y' ? 'selected' : ''; ?>>DD/MM/YYYY</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="items_per_page" class="form-label">Items Per Page</label>
                                                        <input type="number" class="form-control" id="items_per_page" name="items_per_page" 
                                                               value="<?php echo $system_config['items_per_page']; ?>" min="5" max="100">
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-save me-1"></i>Save Configuration
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>System Information</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-2">
                                            <small class="text-muted">PHP Version</small>
                                            <div class="fw-bold"><?php echo PHP_VERSION; ?></div>
                                        </div>
                                        <div class="mb-2">
                                            <small class="text-muted">Server</small>
                                            <div class="fw-bold"><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></div>
                                        </div>
                                        <div class="mb-2">
                                            <small class="text-muted">Database</small>
                                            <div class="fw-bold">MySQL</div>
                                        </div>
                                        <div class="mb-2">
                                            <small class="text-muted">Current User</small>
                                            <div class="fw-bold"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
                                        </div>
                                        <div class="mb-0">
                                            <small class="text-muted">Last Updated</small>
                                            <div class="fw-bold"><?php echo date('F d, Y \a\t h:i A'); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Backup Settings -->
                    <div class="tab-pane fade <?php echo $activeTab === 'backup' ? 'show active' : ''; ?>" 
                         id="backup" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0"><i class="fas fa-database me-2"></i>Database Backup</h5>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST">
                                            <input type="hidden" name="action" value="backup_database">
                                            <div class="mb-3">
                                                <label class="form-label">Backup Type</label>
                                                <select class="form-select">
                                                    <option>Full Database Backup</option>
                                                    <option>Members Only</option>
                                                    <option>Events Only</option>
                                                    <option>Attendance Only</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Backup Format</label>
                                                <select class="form-select">
                                                    <option>SQL Dump</option>
                                                    <option>CSV Export</option>
                                                    <option>JSON Export</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="include_media" checked>
                                                    <label class="form-check-label" for="include_media">
                                                        Include uploaded files and media
                                                    </label>
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-success">
                                                <i class="fas fa-download me-1"></i>Create Backup
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0"><i class="fas fa-history me-2"></i>Recent Backups</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Full Backup</span>
                                                <small class="text-muted"><?php echo date('M d, Y'); ?></small>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Size: 2.5 MB</span>
                                                <button class="btn btn-sm btn-outline-primary">Download</button>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Members Only</span>
                                                <small class="text-muted"><?php echo date('M d, Y', strtotime('-1 day')); ?></small>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Size: 1.2 MB</span>
                                                <button class="btn btn-sm btn-outline-primary">Download</button>
                                            </div>
                                        </div>
                                        <div class="mb-0">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Events Only</span>
                                                <small class="text-muted"><?php echo date('M d, Y', strtotime('-2 days')); ?></small>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Size: 0.8 MB</span>
                                                <button class="btn btn-sm btn-outline-primary">Download</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tools Settings -->
                    <div class="tab-pane fade <?php echo $activeTab === 'tools' ? 'show active' : ''; ?>" 
                         id="tools" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0"><i class="fas fa-tools me-2"></i>System Tools</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="mb-4">
                                                    <h6><i class="fas fa-trash me-2"></i>Data Management</h6>
                                                    <p class="text-muted">Clear system data and records</p>
                                                    <div class="d-grid gap-2">
                                                        <form method="POST" onsubmit="return confirm('Are you sure you want to clear all attendance records? This action cannot be undone.')">
                                                            <input type="hidden" name="action" value="clear_attendance">
                                                            <button type="submit" class="btn btn-warning btn-sm">
                                                                <i class="fas fa-trash me-1"></i>Clear Attendance
                                                            </button>
                                                        </form>
                                                        <form method="POST" onsubmit="return confirm('Are you sure you want to clear all announcements? This action cannot be undone.')">
                                                            <input type="hidden" name="action" value="clear_announcements">
                                                            <button type="submit" class="btn btn-warning btn-sm">
                                                                <i class="fas fa-trash me-1"></i>Clear Announcements
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="mb-4">
                                                    <h6><i class="fas fa-broom me-2"></i>Maintenance</h6>
                                                    <p class="text-muted">System optimization and cleanup</p>
                                                    <div class="d-grid gap-2">
                                                        <button type="button" class="btn btn-info btn-sm" onclick="clearCache()">
                                                            <i class="fas fa-broom me-1"></i>Clear Cache
                                                        </button>
                                                        <button type="button" class="btn btn-info btn-sm" onclick="optimizeDatabase()">
                                                            <i class="fas fa-database me-1"></i>Optimize Database
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0"><i class="fas fa-chart-bar me-2"></i>System Statistics</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Total Members</span>
                                                <span class="fw-bold"><?php echo $stats['total_members']; ?></span>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Total Events</span>
                                                <span class="fw-bold"><?php echo $stats['total_events']; ?></span>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Attendance Records</span>
                                                <span class="fw-bold"><?php echo $stats['total_attendance']; ?></span>
                                            </div>
                                        </div>
                                        <div class="mb-0">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">Announcements</span>
                                                <span class="fw-bold"><?php echo $stats['total_announcements']; ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Settings functionality
    function exportSettings() {
        if (confirm('Export current settings to file?')) {
            showNotification('Settings exported successfully!', 'success');
        }
    }

    function resetSettings() {
        if (confirm('Reset all settings to default values? This action cannot be undone.')) {
            showNotification('Settings reset to default!', 'info');
        }
    }

    function clearCache() {
        if (confirm('Clear system cache?')) {
            showNotification('Cache cleared successfully!', 'success');
        }
    }

    function optimizeDatabase() {
        if (confirm('Optimize database tables?')) {
            showNotification('Database optimized successfully!', 'success');
        }
    }

    function showNotification(message, type) {
        // Create notification element
        var notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'} me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    // Password strength indicator (accurate scoring)
    (function () {
        var newPasswordInput = document.getElementById('new_password');
        if (!newPasswordInput) return;
        var indicator = document.getElementById('password-strength');
        function scorePassword(pw) {
            if (!pw) return 0;
            var score = 0;
            // length
            if (pw.length >= 12) score += 3; else if (pw.length >= 10) score += 2; else if (pw.length >= 8) score += 1;
            // classes
            var hasLower = /[a-z]/.test(pw);
            var hasUpper = /[A-Z]/.test(pw);
            var hasDigit = /\d/.test(pw);
            var hasSymbol = /[^A-Za-z0-9]/.test(pw);
            var classes = [hasLower, hasUpper, hasDigit, hasSymbol].filter(Boolean).length;
            score += classes; // +1 per class
            // penalties
            if (/^(.)\1{2,}$/.test(pw)) score -= 2; // triple repeats
            if (/^[A-Za-z]+$/.test(pw) || /^\d+$/.test(pw)) score -= 1; // single class only
            if (/(password|1234|qwer|admin|smart|union)/i.test(pw)) score -= 2; // common words
            return Math.max(0, Math.min(8, score));
        }
        function render(score) {
            var levels = [
                { text: 'Very Weak', cls: 'danger' },
                { text: 'Weak', cls: 'warning' },
                { text: 'Fair', cls: 'info' },
                { text: 'Good', cls: 'success' },
                { text: 'Strong', cls: 'success' }
            ];
            var idx = 0;
            if (score >= 7) idx = 4; else if (score >= 5) idx = 3; else if (score >= 3) idx = 2; else if (score >= 1) idx = 1; else idx = 0;
            if (indicator) {
                indicator.textContent = levels[idx].text;
                indicator.className = 'badge bg-' + levels[idx].cls;
            }
        }
        function handle() { render(scorePassword(newPasswordInput.value || '')); }
        newPasswordInput.addEventListener('input', handle);
        handle();
    })();
    </script>
    
    <style>
        .avatar-lg {
            width: 80px;
            height: 80px;
        }
        
        .nav-pills .nav-link {
            border-radius: 0.5rem;
            margin: 0 0.25rem;
        }
        
        .nav-pills .nav-link.active {
            background-color: #0d6efd;
        }
        
        .card {
            transition: transform 0.2s ease-in-out;
        }
        
        .card:hover {
            transform: translateY(-2px);
        }
        
        .form-check-input:checked {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        
        .border-left-primary {
            border-left: 0.25rem solid #4e73df !important;
        }
        
        .border-left-success {
            border-left: 0.25rem solid #1cc88a !important;
        }
        
        .border-left-info {
            border-left: 0.25rem solid #36b9cc !important;
        }
        
        .border-left-warning {
            border-left: 0.25rem solid #f6c23e !important;
        }
    </style>
</body>
</html>
