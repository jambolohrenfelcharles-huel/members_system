<?php
session_start();
require_once '../config/database.php';
require_once '../config/email_config.php';
require_once '../config/smtp_email.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get current user info
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$errors = [];
$success = '';

// Email configuration
function sendEmailNotification($to, $subject, $message, $from = null) {
    // Use configured email settings
    $config = getEmailConfig();
    $fromAddress = $from ?: $config['from_address'];
    $fromName = $config['from_name'];
    
    // Check if we're on localhost and should simulate
    $isLocalhost = in_array($_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1', '::1']);
    if ($isLocalhost && $config['simulate_on_localhost']) {
        // Simulate email sending on localhost
        if ($config['log_attempts']) {
            error_log("Email simulation: To=$to, Subject=$subject, From=$fromAddress, Result=Simulated");
        }
        return true; // Return true to simulate success
    }
    
    // Try SMTP first if configured
    if (!empty($config['smtp_host']) && $config['smtp_host'] !== 'localhost' && !empty($config['smtp_username'])) {
        $result = sendEmailViaSMTP($to, $subject, $message, $fromAddress, $fromName);
        if ($result) {
            return true;
        }
        // If SMTP fails, fall back to PHP mail()
    }
    
    // Fallback to PHP mail() function
    if (!function_exists('mail')) {
        return false;
    }
    
    // Create proper headers
    $headers = array();
    $headers[] = "MIME-Version: 1.0";
    $headers[] = "Content-Type: text/html; charset=" . $config['charset'];
    $headers[] = "From: $fromName <$fromAddress>";
    $headers[] = "Reply-To: " . $config['reply_to'];
    $headers[] = "X-Mailer: PHP/" . phpversion();
    $headers[] = "X-Priority: " . $config['priority'];
    
    $headerString = implode("\r\n", $headers);
    
    // Try to send email
    $result = @mail($to, $subject, $message, $headerString);
    
    // Log the attempt (for debugging)
    if ($config['log_attempts']) {
        error_log("Email attempt: To=$to, Subject=$subject, From=$fromAddress, Result=" . ($result ? 'Success' : 'Failed'));
    }
    
    return $result;
}

function sendTestEmail($email) {
    $subject = "Test Email - SmartUnion System";
    $message = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>Test Email</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #007bff; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f8f9fa; }
            .footer { padding: 10px; text-align: center; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>SmartUnion System</h1>
            </div>
            <div class='content'>
                <h2>Email Test Successful!</h2>
                <p>Hello,</p>
                <p>This is a test email from your SmartUnion membership system.</p>
                <p>If you received this email, your email notifications are working correctly.</p>
                <p>You can now receive important notifications about your account and system updates.</p>
            </div>
            <div class='footer'>
                <p>Sent on " . date('F d, Y \a\t h:i A') . "</p>
                <p>SmartUnion Membership System</p>
            </div>
        </div>
    </body>
    </html>";
    
    return sendEmailNotification($email, $subject, $message);
}

function checkEmailConfiguration() {
    $emailConfig = getEmailConfig();
    $emailStatus = getEmailStatus();
    
    $config = array();
    
    // Check if mail function exists
    $config['mail_function'] = $emailStatus['mail_function'];
    
    // Check sendmail path (common on Unix systems)
    $config['sendmail_path'] = ini_get('sendmail_path');
    
    // Check SMTP settings
    $config['smtp_host'] = $emailConfig['smtp_host'];
    $config['smtp_port'] = $emailConfig['smtp_port'];
    $config['smtp_configured'] = $emailStatus['smtp_configured'];
    $config['smtp_username'] = $emailConfig['smtp_username'];
    $config['smtp_encryption'] = $emailConfig['smtp_encryption'];
    
    // Check if running on localhost (common development issue)
    $config['is_localhost'] = $emailStatus['is_localhost'];
    
    // Check if email is properly configured
    $config['properly_configured'] = $emailStatus['configured'];
    
    // Get from address
    $config['from_address'] = $emailConfig['from_address'];
    
    // Check if SMTP is ready for actual sending
    $config['smtp_ready'] = !empty($emailConfig['smtp_host']) && 
                           $emailConfig['smtp_host'] !== 'localhost' && 
                           !empty($emailConfig['smtp_username']) && 
                           !empty($emailConfig['smtp_password']);
    
    return $config;
}

// Avatar setup and helpers
$avatarDir = __DIR__ . '/uploads/avatars';
if (!is_dir($avatarDir)) {
    @mkdir($avatarDir, 0777, true);
}
$allowedExt = ['jpg','jpeg','png','gif','webp'];
function findUserAvatarBasename($dir, $userId, $exts) {
    foreach ($exts as $ext) {
        $candidate = $dir . '/' . $userId . '.' . $ext;
        if (file_exists($candidate)) {
            return $userId . '.' . $ext;
        }
    }
    return null;
}
function detectImageExtension($tmpPath) {
    if (class_exists('finfo')) {
        $fi = new finfo(FILEINFO_MIME_TYPE);
        $mime = $fi->file($tmpPath) ?: '';
        $map = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/gif' => 'gif',
            'image/webp' => 'webp',
        ];
        if (isset($map[$mime])) {
            return $map[$mime];
        }
    }
    $info = @getimagesize($tmpPath);
    if (is_array($info) && isset($info[2])) {
        switch ($info[2]) {
            case IMAGETYPE_JPEG: return 'jpg';
            case IMAGETYPE_PNG: return 'png';
            case IMAGETYPE_GIF: return 'gif';
            case IMAGETYPE_WEBP: return 'webp';
        }
    }
    return null;
}
$currentAvatarBasename = findUserAvatarBasename($avatarDir, $user['id'], $allowedExt);

if ($_POST) {
    if (isset($_POST['upload_avatar'])) {
        if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = "Please select an image to upload.";
        } else {
            $fileTmp = $_FILES['avatar']['tmp_name'];
            $fileSize = (int)$_FILES['avatar']['size'];
            if (!is_uploaded_file($fileTmp)) {
                $errors[] = 'Invalid upload source.';
            } elseif ($fileSize <= 0 || $fileSize > 500 * 1024 * 1024) {
                $errors[] = 'Image must be between 1 byte and 500MB.';
            } else {
                $ext = detectImageExtension($fileTmp);
                if (!$ext) {
                    $errors[] = 'Only JPG, PNG, GIF, or WEBP images are allowed.';
                } else {
                    // Remove old avatar files with different extensions
                    foreach ($allowedExt as $e) {
                        $old = $avatarDir . '/' . $user['id'] . '.' . $e;
                        if (file_exists($old)) {
                            @unlink($old);
                        }
                    }
                    $targetPath = $avatarDir . '/' . $user['id'] . '.' . $ext;
                    if (!@move_uploaded_file($fileTmp, $targetPath)) {
                        $errors[] = 'Failed to save uploaded image.';
                    } else {
                        @chmod($targetPath, 0644);
                        $success = 'Profile picture updated successfully!';
                        $currentAvatarBasename = $user['id'] . '.' . $ext;
                    }
                }
            }
        }
    } elseif (isset($_POST['test_email'])) {
        $email = trim($_POST['email'] ?? '');
        if (empty($email)) {
            $errors[] = "Email address is required for testing";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format";
        } else {
            // Check email configuration first
            $emailConfig = checkEmailConfiguration();
            
            if (!$emailConfig['mail_function']) {
                $errors[] = "Mail function is not available on this server.";
            } else {
                if (sendTestEmail($email)) {
                    if ($emailConfig['is_localhost']) {
                        $success = "Test email simulation completed successfully! Note: You're running on localhost, so this was simulated. In a production environment, this would send a real email to $email.";
                    } else {
                        $success = "Test email sent successfully to $email! Please check your inbox (and spam folder).";
                    }
                } else {
                    $errors[] = "Failed to send test email. This could be due to server email configuration. Please contact your system administrator.";
                }
            }
        }
    } else {
        $new_username = isset($_POST['username']) ? trim($_POST['username']) : '';
        $new_email = isset($_POST['email']) ? trim($_POST['email']) : '';
        $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';
        $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

        if ($new_username === '') {
            $errors[] = "Username is required";
        } else {
            // Check if username is taken by another user
            $check = $db->prepare("SELECT id FROM users WHERE username = ? AND id <> ? LIMIT 1");
            $check->execute([$new_username, $_SESSION['user_id']]);
            if ($check->fetch(PDO::FETCH_ASSOC)) {
                $errors[] = "Username is already taken";
            }
        }

        if ($new_email === '') {
            $errors[] = "Email address is required";
        } elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format";
        } else {
            // Check if email is taken by another user
            $check = $db->prepare("SELECT id FROM users WHERE email = ? AND id <> ? LIMIT 1");
            $check->execute([$new_email, $_SESSION['user_id']]);
            if ($check->fetch(PDO::FETCH_ASSOC)) {
                $errors[] = "Email address is already taken";
            }
        }

        if (!empty($new_password)) {
            if (strlen($new_password) < 6) {
                $errors[] = "Password must be at least 6 characters long";
            }
            if ($new_password !== $confirm_password) {
                $errors[] = "Passwords do not match";
            }
        }

        if (empty($errors)) {
            $email_changed = ($new_email !== $user['email']);
            
            if (!empty($new_password)) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $db->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
                $result = $stmt->execute([$new_username, $new_email, $hashed_password, $_SESSION['user_id']]);
            } else {
                $stmt = $db->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
                $result = $stmt->execute([$new_username, $new_email, $_SESSION['user_id']]);
            }

            if ($result) {
                $_SESSION['username'] = $new_username;
                
                // Send email notification if email was changed
                if ($email_changed) {
                    $subject = "Email Address Updated - SmartUnion";
                    $message = "
                    <html>
                    <head>
                        <title>Email Address Updated</title>
                    </head>
                    <body>
                        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
                            <h2 style='color: #333;'>Email Address Updated</h2>
                            <p>Hello " . htmlspecialchars($new_username) . ",</p>
                            <p>Your email address has been successfully updated to: <strong>" . htmlspecialchars($new_email) . "</strong></p>
                            <p>If you did not make this change, please contact your administrator immediately.</p>
                            <hr style='border: 1px solid #eee; margin: 20px 0;'>
                            <p style='color: #666; font-size: 12px;'>
                                This email was sent on " . date('F d, Y \a\t h:i A') . "<br>
                                SmartUnion Membership System
                            </p>
                        </div>
                    </body>
                    </html>";
                    
                    sendEmailNotification($new_email, $subject, $message);
                }
                
                $success = !empty($new_password) ? "Profile updated successfully! Email notification sent." : "Profile updated successfully!";
            } else {
                $errors[] = "Failed to update profile";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Membership System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/dashboard.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include __DIR__ . '/includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><i class="fas fa-user me-2"></i>Profile</h1>
                </div>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger" role="alert">
                        <h6><i class="fas fa-exclamation-triangle me-2"></i>Please fix the following errors:</h6>
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success" role="alert">
                        <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-lg-6">
                        <div class="card mb-3">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-image me-2"></i>Profile Picture</h5>
                            </div>
                            <div class="card-body text-center">
                                <?php if ($currentAvatarBasename): ?>
                                    <img src="uploads/avatars/<?php echo htmlspecialchars($currentAvatarBasename); ?>?v=<?php echo time(); ?>" alt="Profile Picture" class="rounded-circle mb-3" style="width: 128px; height: 128px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 128px; height: 128px;">
                                        <i class="fas fa-user text-muted" style="font-size: 48px;"></i>
                                    </div>
                                <?php endif; ?>
                                <form method="POST" enctype="multipart/form-data">
                                    <div class="mb-2">
                                        <input type="file" name="avatar" accept="image/*" class="form-control" required>
                                    </div>
                                    <button type="submit" name="upload_avatar" value="1" class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-upload me-1"></i>Upload New Picture
                                    </button>
                                    <div class="form-text mt-2">Max 500MB. JPG, PNG, GIF, or WEBP.</div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                </div>

                
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    function testEmail() {
        // Get the current email value from the form
        var currentEmail = document.getElementById('email').value;
        document.getElementById('test_email_address').value = currentEmail;
        
        // Show the modal
        var modal = new bootstrap.Modal(document.getElementById('testEmailModal'));
        modal.show();
    }
    
    // Password strength indicator
    document.getElementById('new_password')?.addEventListener('input', function() {
        var password = this.value;
        var strength = 0;
        
        if (password.length >= 6) strength++;
        if (password.match(/[a-z]/)) strength++;
        if (password.match(/[A-Z]/)) strength++;
        if (password.match(/[0-9]/)) strength++;
        if (password.match(/[^a-zA-Z0-9]/)) strength++;
        
        var strengthText = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];
        var strengthClass = ['danger', 'warning', 'info', 'success', 'success'];
        
        // Update strength indicator if element exists
        var indicator = document.getElementById('password-strength');
        if (indicator) {
            indicator.textContent = strengthText[strength] || 'Very Weak';
            indicator.className = `badge bg-${strengthClass[strength] || 'danger'}`;
        }
    });
    </script>
</body>
</html>