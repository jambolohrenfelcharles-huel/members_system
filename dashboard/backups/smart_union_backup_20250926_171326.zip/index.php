<?php
// Redirect to login page
header('Location: auth/login.php');
exit();
?>
